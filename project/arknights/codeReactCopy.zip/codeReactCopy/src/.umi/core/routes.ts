// @ts-nocheck
import React from 'react';
import { ApplyPluginsType } from 'D:/gitProject/learn/project/arknights/codeReact/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';

export function getRoutes() {
  const routes = [
  {
    "path": "/",
    "component": require('@/layouts/index.js').default,
    "routes": [
      {
        "path": "/announcement",
        "exact": true,
        "component": require('@/pages/announcement/index.js').default
      },
      {
        "path": "/background",
        "exact": true,
        "component": require('@/pages/background/index.js').default
      },
      {
        "path": "/characterMain",
        "exact": true,
        "component": require('@/pages/characterMain/index.js').default
      },
      {
        "path": "/eventDetail",
        "exact": true,
        "component": require('@/pages/eventDetail/index.js').default
      },
      {
        "path": "/",
        "exact": true,
        "component": require('@/pages/index/index.js').default
      },
      {
        "path": "/latestEvents",
        "exact": true,
        "component": require('@/pages/latestEvents/index.js').default
      },
      {
        "path": "/news",
        "exact": true,
        "component": require('@/pages/news/index.js').default
      },
      {
        "path": "/rhodesIland",
        "exact": true,
        "component": require('@/pages/rhodesIland/index.js').default
      },
      {
        "path": "/user",
        "exact": true,
        "component": require('@/pages/user/index.js').default
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
