export default {
    namespace: 'rhodesIland',
    state: {
    },
    reducers: {
    },
    effects: {
    },
    subscriptions: {},
};
