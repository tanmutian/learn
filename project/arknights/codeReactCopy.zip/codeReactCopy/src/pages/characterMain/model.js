export default {
    namespace: 'characterMain2',
    state: {
    },
    reducers: {
    },
    effects: {
    },
    subscriptions: {},
};
