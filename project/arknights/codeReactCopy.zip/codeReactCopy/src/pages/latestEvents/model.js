export default {
    namespace: 'latestEvents',
    state: {
    },
    reducers: {
    },
    effects: {
    },
    subscriptions: {},
};
