export default {
    namespace: 'eventDetail',
    state: {
    },
    reducers: {
    },
    effects: {
    },
    subscriptions: {},
};
