export default {
    namespace: 'news',
    state: {
    },
    reducers: {
    },
    effects: {
    },
    subscriptions: {},
};
