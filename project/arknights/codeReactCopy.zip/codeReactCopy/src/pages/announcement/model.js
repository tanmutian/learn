export default {
    namespace: 'announcement',
    state: {
    },
    reducers: {
    },
    effects: {
    },
    subscriptions: {},
};
