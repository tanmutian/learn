export default {
    namespace: 'background',
    state: {
    },
    reducers: {
    },
    effects: {
    },
    subscriptions: {},
};
